"""
scripts/init_db.py
------------------
Utility script to initialize / reset the database.

Usage:
    python scripts/init_db.py           # Create tables + seed admin
    python scripts/init_db.py --reset   # DROP all tables, then recreate
"""

import sys
import os

# Add project root to path so we can import 'app'
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app import create_app, db
from app.models.user import User
from app.models.report import Report


def init_database(reset: bool = False):
    app = create_app("development")

    with app.app_context():
        if reset:
            print("⚠  Dropping all tables...")
            db.drop_all()
            print("✅ Dropped.")

        print("🔧 Creating tables...")
        db.create_all()
        print("✅ Tables created.")

        # Check if admin already exists
        existing_admin = User.query.filter_by(role="admin").first()
        if existing_admin:
            print(f"ℹ  Admin already exists: {existing_admin.email}")
        else:
            admin = User(
                username="admin",
                email=os.getenv("ADMIN_EMAIL", "admin@researchai.com"),
                role="admin",
                plan="enterprise",
                is_active=True,
            )
            admin.set_password(os.getenv("ADMIN_PASSWORD", "Admin@12345"))
            db.session.add(admin)
            db.session.commit()
            print(f"✅ Admin created: {admin.email}")

        # Stats
        print(f"\n📊 Database Summary:")
        print(f"   Users:   {User.query.count()}")
        print(f"   Reports: {Report.query.count()}")
        print("\n✅ Database ready!")


if __name__ == "__main__":
    reset_flag = "--reset" in sys.argv
    if reset_flag:
        confirm = input("⚠  This will DELETE all data. Type 'yes' to confirm: ")
        if confirm.lower() != "yes":
            print("Cancelled.")
            sys.exit(0)
    init_database(reset=reset_flag)
