"""
scripts/test_app.py
--------------------
Quick health-check script.
Runs without a browser — verifies core components work.

Usage:
    python scripts/test_app.py
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))


def test_imports():
    print("🔍 Testing imports...")
    try:
        import flask; print(f"   ✅ Flask {flask.__version__}")
        import flask_sqlalchemy; print("   ✅ Flask-SQLAlchemy")
        import flask_login; print("   ✅ Flask-Login")
        import flask_bcrypt; print("   ✅ Flask-Bcrypt")
        import anthropic; print(f"   ✅ Anthropic SDK")
        import duckduckgo_search; print("   ✅ DuckDuckGo Search")
        import bs4; print(f"   ✅ BeautifulSoup4")
        import reportlab; print(f"   ✅ ReportLab")
        import docx; print("   ✅ python-docx")
        return True
    except ImportError as e:
        print(f"   ❌ Import error: {e}")
        print("   Run: pip install -r requirements.txt")
        return False


def test_app_creation():
    print("\n🔍 Testing app creation...")
    try:
        from app import create_app
        app = create_app("testing")
        print("   ✅ App created successfully")
        return app
    except Exception as e:
        print(f"   ❌ App creation failed: {e}")
        return None


def test_database(app):
    print("\n🔍 Testing database...")
    try:
        with app.app_context():
            from app import db
            from app.models.user import User
            from app.models.report import Report
            db.create_all()
            count = User.query.count()
            print(f"   ✅ Database OK — {count} user(s) in DB")
        return True
    except Exception as e:
        print(f"   ❌ Database error: {e}")
        return False


def test_search():
    print("\n🔍 Testing web search (requires internet)...")
    try:
        from app.services.search_service import search_web
        results = search_web("Python programming", max_results=2)
        if results:
            print(f"   ✅ Search returned {len(results)} results")
            print(f"   First result: {results[0]['title'][:60]}")
        else:
            print("   ⚠  Search returned 0 results (may be rate limited)")
        return True
    except Exception as e:
        print(f"   ❌ Search failed: {e}")
        return False


def test_env():
    print("\n🔍 Checking environment variables...")
    from dotenv import load_dotenv
    load_dotenv()
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if api_key and not api_key.startswith("your-"):
        print("   ✅ ANTHROPIC_API_KEY is set")
    else:
        print("   ⚠  ANTHROPIC_API_KEY not set — using fallback mode")

    secret = os.getenv("SECRET_KEY", "")
    if secret and secret != "change-this-to-a-random-secret-key-in-production":
        print("   ✅ SECRET_KEY is set")
    else:
        print("   ⚠  SECRET_KEY is using default value — change for production!")


if __name__ == "__main__":
    print("=" * 50)
    print("  ResearchAI — System Health Check")
    print("=" * 50)

    ok = test_imports()
    if not ok:
        sys.exit(1)

    app = test_app_creation()
    if not app:
        sys.exit(1)

    test_database(app)
    test_env()
    test_search()

    print("\n" + "=" * 50)
    print("  ✅ All core checks passed!")
    print("  Run:  python run.py")
    print("=" * 50)
