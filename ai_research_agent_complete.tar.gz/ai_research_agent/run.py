"""
run.py
------
Application entry point.

HOW TO RUN:
  python run.py

This file creates the Flask app using the factory in app/__init__.py
and starts the development server.
"""

import os
from app import create_app

# Read which config to use from the environment (default: development)
config_name = os.getenv("FLASK_ENV", "development")

# Create the app
app = create_app(config_name)

if __name__ == "__main__":
    print("=" * 55)
    print("  🔬 ResearchAI — AI Research Agent SaaS")
    print("=" * 55)
    print(f"  Environment : {config_name}")
    print(f"  Debug mode  : {app.config['DEBUG']}")
    print(f"  Database    : {app.config['SQLALCHEMY_DATABASE_URI']}")
    print(f"  AI API Key  : {'✅ Set' if app.config.get('ANTHROPIC_API_KEY') else '❌ NOT SET (fallback mode)'}")
    print("=" * 55)
    print("  Open in browser: http://127.0.0.1:5000")
    print("=" * 55)

    app.run(
        host="0.0.0.0",
        port=int(os.getenv("PORT", 5000)),
        debug=app.config["DEBUG"],
        use_reloader=True,
    )
