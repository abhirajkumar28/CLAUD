# 🔬 ResearchAI — AI-Powered Research Agent SaaS

A complete, production-ready SaaS application that uses Claude AI + web search
to generate professional research reports — with user accounts, admin panel,
PDF/DOCX export, and subscription plans.

---

## 📁 Project Structure (Every File Explained)

```
ai_research_agent/
│
├── run.py                    ← START HERE: launches the app
├── requirements.txt          ← all Python packages needed
├── .env                      ← your secret keys (never commit to Git!)
├── .env.example              ← template for .env
├── .gitignore                ← files Git should ignore
├── gunicorn.conf.py          ← production server settings
├── nginx.conf                ← web server config (production)
├── researchai.service        ← Linux auto-start config
├── setup_windows.bat         ← one-click Windows setup
├── setup_linux.sh            ← one-click Linux/Mac setup
│
├── app/                      ← main application package
│   ├── __init__.py           ← creates the Flask app, registers blueprints
│   ├── config.py             ← settings for dev/prod/test environments
│   │
│   ├── models/               ← database table definitions
│   │   ├── user.py           ← User table (accounts, plans, roles)
│   │   └── report.py         ← Report table (research results)
│   │
│   ├── routes/               ← URL handlers (what happens at each URL)
│   │   ├── auth.py           ← /auth/login, /auth/signup, /auth/logout
│   │   ├── dashboard.py      ← /dashboard/ (home, history, pricing)
│   │   ├── research.py       ← /research/new, /research/report/<id>
│   │   ├── admin.py          ← /admin/ (user mgmt, report mgmt)
│   │   └── api.py            ← /api/ (JSON endpoints for JavaScript)
│   │
│   ├── services/             ← business logic (the "brain")
│   │   ├── search_service.py ← DuckDuckGo search + page scraping
│   │   ├── ai_service.py     ← Claude AI report generation
│   │   ├── research_service.py ← orchestrates the full pipeline
│   │   └── export_service.py ← PDF and DOCX generation
│   │
│   └── templates/            ← HTML pages
│       ├── base.html         ← shared layout (sidebar, navbar, CSS)
│       ├── auth/
│       │   ├── login.html    ← login page
│       │   └── signup.html   ← registration page
│       ├── dashboard/
│       │   ├── home.html     ← user dashboard with stats
│       │   ├── history.html  ← paginated list of all reports
│       │   └── pricing.html  ← subscription plans
│       ├── research/
│       │   ├── new.html      ← "Start Research" form
│       │   └── report.html   ← view a single report + export buttons
│       └── admin/
│           ├── dashboard.html ← admin overview
│           ├── users.html     ← manage all users
│           └── reports.html   ← manage all reports
│
├── scripts/
│   ├── init_db.py            ← set up / reset the database
│   └── test_app.py           ← health check (run before starting)
│
├── exports/                  ← generated PDF and DOCX files saved here
├── migrations/               ← database migration history (Flask-Migrate)
└── docs/                     ← extra documentation
```

---

## 🚀 Quick Start (Beginner-Friendly)

### Step 1 — Download / Clone the Project

```bash
# If using Git:
git clone https://github.com/yourusername/ai_research_agent.git
cd ai_research_agent

# Or just copy the folder to your computer
```

### Step 2 — Get Your Free API Key

1. Go to **https://console.anthropic.com**
2. Sign up (free account)
3. Click **"API Keys"** → **"Create Key"**
4. Copy the key (starts with `sk-ant-...`)

### Step 3 — Set Up on Windows

```batch
REM Double-click setup_windows.bat, OR run in Command Prompt:
setup_windows.bat
```

Then edit `.env` with Notepad, find this line, and paste your key:
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

### Step 4 — Set Up on Linux / Mac

```bash
chmod +x setup_linux.sh
./setup_linux.sh

# Then edit .env:
nano .env
# Find ANTHROPIC_API_KEY= and paste your key
```

### Step 5 — Run the App

**Windows:**
```batch
venv\Scripts\activate
python run.py
```

**Linux/Mac:**
```bash
source venv/bin/activate
python run.py
```

### Step 6 — Open in Browser

```
http://127.0.0.1:5000
```

**Default admin login:**
- Email: `admin@researchai.com`
- Password: `Admin@12345`

---

## 🗄️ Database Setup

The app uses **SQLite** by default — no installation needed, it's a single file.

The database is created automatically when you run `python run.py`.

### To manually initialize the database:
```bash
python scripts/init_db.py
```

### To reset (delete all data and start fresh):
```bash
python scripts/init_db.py --reset
```

### To upgrade to PostgreSQL (for production):
1. Install PostgreSQL on your server
2. Create a database: `CREATE DATABASE researchai;`
3. Update `.env`:
   ```
   DATABASE_URL=postgresql://username:password@localhost:5432/researchai
   ```
4. Install the driver: `pip install psycopg2-binary`
5. Run: `python scripts/init_db.py`

---

## 💰 Monetization Options

### Option 1 — Stripe Subscriptions (Recommended)

1. Sign up at **https://stripe.com**
2. Get your API keys from the Stripe Dashboard
3. Add to `.env`:
   ```
   STRIPE_PUBLIC_KEY=pk_live_...
   STRIPE_SECRET_KEY=sk_live_...
   ```
4. Create products in Stripe Dashboard for Basic ($9), Pro ($29), Enterprise ($99)
5. Add Stripe Checkout to `app/routes/dashboard.py`

**Basic Stripe integration:**
```python
import stripe
stripe.api_key = os.getenv('STRIPE_SECRET_KEY')

@dashboard_bp.route('/checkout/<plan>')
@login_required
def checkout(plan):
    prices = {'basic': 'price_xxx', 'pro': 'price_yyy', 'enterprise': 'price_zzz'}
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{'price': prices[plan], 'quantity': 1}],
        mode='subscription',
        success_url=url_for('dashboard.home', _external=True) + '?success=1',
        cancel_url=url_for('dashboard.pricing', _external=True),
    )
    return redirect(session.url)
```

### Option 2 — Manual Bank Transfer (Simplest for India)
- Show your UPI/bank details on the pricing page
- Admin manually upgrades user plan in Admin Panel
- Perfect for bootstrapping

### Option 3 — Razorpay (Best for India)
- Sign up at **https://razorpay.com**
- Similar integration to Stripe but works with Indian payments

### Option 4 — API Access (B2B)
- Sell API keys to developers who want to build on top of your platform
- Charge per 1000 API calls

---

## 🚀 Deployment Guide

### Deploy on a VPS (DigitalOcean / AWS / Hetzner)

**Recommended server:** Ubuntu 22.04 LTS, 2GB RAM, 1 CPU (~$6/month on Hetzner)

```bash
# 1. SSH into your server
ssh ubuntu@your-server-ip

# 2. Install dependencies
sudo apt update && sudo apt install -y python3 python3-pip python3-venv nginx git

# 3. Clone your project
git clone https://github.com/yourusername/ai_research_agent.git
cd ai_research_agent

# 4. Run setup
chmod +x setup_linux.sh && ./setup_linux.sh

# 5. Edit .env with your production values
nano .env
# Set: FLASK_ENV=production
# Set: SECRET_KEY=<random 32-char string>
# Set: ANTHROPIC_API_KEY=<your key>

# 6. Create logs directory
mkdir -p logs

# 7. Install as system service
sudo cp researchai.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable researchai
sudo systemctl start researchai

# 8. Set up Nginx
sudo cp nginx.conf /etc/nginx/sites-available/researchai
# Edit server_name in the file:
sudo nano /etc/nginx/sites-available/researchai
sudo ln -s /etc/nginx/sites-available/researchai /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl restart nginx

# 9. Free HTTPS with Let's Encrypt
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### Deploy on Railway (Easiest — Free tier available)

1. Push code to GitHub
2. Go to **https://railway.app**
3. Click **"Deploy from GitHub"**
4. Add environment variables in Railway dashboard
5. Done! Railway auto-detects Python and runs `gunicorn`

### Deploy on Render (Also Easy — Free tier)

1. Push to GitHub
2. Go to **https://render.com**
3. New → Web Service → Connect repo
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn "app:create_app('production')"`
6. Add environment variables

---

## 🔮 Future Upgrade Roadmap

### Phase 2 (Month 2-3)
- [ ] **Email verification** on signup (Flask-Mail)
- [ ] **Password reset** via email
- [ ] **Real Stripe billing** with webhooks
- [ ] **Report sharing** via public links
- [ ] **Search filters** (by date, status, topic)

### Phase 3 (Month 4-6)
- [ ] **Celery + Redis** for proper background job queue (replaces threads)
- [ ] **Real-time progress** via WebSockets (Flask-SocketIO)
- [ ] **Custom AI personas** (Research Analyst, Legal Expert, etc.)
- [ ] **Team accounts** (one company, multiple users)
- [ ] **Scheduled research** (daily/weekly auto-reports)

### Phase 4 (Month 7-12)
- [ ] **API access** for developers
- [ ] **Chrome extension** for one-click research
- [ ] **Google Docs integration** (export directly to Drive)
- [ ] **Citation manager** (auto-format references)
- [ ] **Multi-language** reports
- [ ] **White-label** for resellers
- [ ] **Affiliate program**

---

## 🛡️ Security Checklist

Before going live, verify these:

- [ ] `SECRET_KEY` is a random 32+ character string (not the default)
- [ ] `FLASK_DEBUG=0` in production
- [ ] `ANTHROPIC_API_KEY` is in `.env`, not in code
- [ ] `.env` is in `.gitignore` (never push to GitHub!)
- [ ] HTTPS is enabled (Let's Encrypt / Nginx)
- [ ] Strong admin password (not `Admin@12345`)
- [ ] Database backups set up (cron job)
- [ ] Rate limiting added to login route (Flask-Limiter)

---

## 🐛 Troubleshooting

### "ModuleNotFoundError"
```bash
# Make sure virtual environment is active:
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows
pip install -r requirements.txt
```

### "No reports being generated"
- Check your `ANTHROPIC_API_KEY` in `.env`
- Check your internet connection (needed for web search)
- Run: `python scripts/test_app.py`

### "Database error"
```bash
# Reset the database:
python scripts/init_db.py --reset
```

### "Port 5000 already in use"
```bash
# Change port in run.py, or kill the process using it:
# Linux: lsof -i :5000 | kill -9 <PID>
# Windows: netstat -ano | findstr :5000 → taskkill /PID <PID> /F
```

---

## 📞 Support & Contact

- Logs are in `logs/error.log` (production) or terminal (development)
- Admin panel: `http://yoursite.com/admin`
- Health check: `python scripts/test_app.py`
