# ============================================================
# gunicorn.conf.py
# Production server configuration for Linux deployments
# Usage:  gunicorn -c gunicorn.conf.py "app:create_app('production')"
# ============================================================

import multiprocessing
import os

# ── Binding ───────────────────────────────────────────────────
bind = f"0.0.0.0:{os.getenv('PORT', '5000')}"

# ── Workers ───────────────────────────────────────────────────
# Rule of thumb: (2 × CPU cores) + 1
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"
threads = 2
timeout = 120           # seconds before killing a stuck worker
keepalive = 5

# ── Logging ───────────────────────────────────────────────────
accesslog = "logs/access.log"
errorlog  = "logs/error.log"
loglevel  = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s %(f)s %(a)s'

# ── Process naming ────────────────────────────────────────────
proc_name = "researchai"

# ── Security ─────────────────────────────────────────────────
limit_request_line    = 4096
limit_request_fields  = 100
limit_request_field_size = 8190
