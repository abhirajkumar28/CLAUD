"""
app/models/user.py
------------------
The User database model.
Stores account info, plan tier, and login credentials.
Flask-Login uses this to manage logged-in sessions.
"""

from datetime import datetime, timezone
from flask_login import UserMixin
from app import db, bcrypt, login_manager


class User(UserMixin, db.Model):
    """Represents a registered user."""

    __tablename__ = "users"

    id         = db.Column(db.Integer, primary_key=True)
    username   = db.Column(db.String(80),  unique=True, nullable=False)
    email      = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=True)  # nullable for OAuth later

    # "user" | "admin"
    role       = db.Column(db.String(20), default="user", nullable=False)

    # "free" | "basic" | "pro" | "enterprise"
    plan       = db.Column(db.String(20), default="free", nullable=False)

    is_active  = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    last_login = db.Column(db.DateTime, nullable=True)

    # Reports this user has created (one-to-many)
    reports = db.relationship("Report", backref="user", lazy="dynamic", cascade="all, delete-orphan")

    # ── Password helpers ──────────────────────────────────────────────────────
    def set_password(self, password: str):
        self.password_hash = bcrypt.generate_password_hash(password).decode("utf-8")

    def check_password(self, password: str) -> bool:
        return bcrypt.check_password_hash(self.password_hash, password)

    # ── Helpers ───────────────────────────────────────────────────────────────
    def is_admin(self) -> bool:
        return self.role == "admin"

    def reports_this_month(self) -> int:
        """Count how many reports this user has created in the current month."""
        now = datetime.now(timezone.utc)
        return self.reports.filter(
            db.extract("month", Report.created_at) == now.month,
            db.extract("year",  Report.created_at) == now.year,
        ).count()

    def __repr__(self):
        return f"<User {self.username} [{self.plan}]>"


# Needed by Flask-Login: loads a user from the DB given their ID
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# Import here to avoid circular imports
from app.models.report import Report  # noqa: E402
