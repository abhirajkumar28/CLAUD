"""
app/services/ai_service.py
---------------------------
Uses the Anthropic Claude API to synthesize research sources
into a professional report with insights and conclusions.
"""

import json
import logging
import os
from typing import List, Dict, Tuple
import anthropic

logger = logging.getLogger(__name__)


def _get_client() -> anthropic.Anthropic:
    key = os.getenv("ANTHROPIC_API_KEY", "")
    if not key:
        raise ValueError("ANTHROPIC_API_KEY is not set in your .env file")
    return anthropic.Anthropic(api_key=key)


def generate_report(topic: str, sources: List[Dict]) -> Tuple[str, str, List[str]]:
    """
    Ask Claude to write a full research report from the gathered sources.

    Returns:
        report_markdown  – full report as Markdown text
        summary          – one-paragraph executive summary
        insights         – list of 5–7 key insight strings
    """
    client = _get_client()

    # Build a compact sources block to include in the prompt
    sources_text = ""
    for i, src in enumerate(sources, 1):
        sources_text += (
            f"\n--- Source {i}: {src['title']} ---\n"
            f"URL: {src['url']}\n"
            f"{src['content'][:2000]}\n"
        )

    prompt = f"""You are an expert research analyst. Based on the following web sources, 
write a comprehensive, professional research report on the topic: "{topic}"

SOURCES:
{sources_text}

Write the report in this EXACT format (use proper Markdown):

# Research Report: {topic}

## Executive Summary
[2-3 paragraph overview of key findings]

## Introduction
[Background and why this topic matters]

## Key Findings
[Detailed findings organized in subsections with ### headings]

## Analysis
[In-depth analysis connecting the findings]

## Current Trends
[What's happening right now]

## Challenges & Considerations
[Problems, risks, or things to watch]

## Conclusions
[Final takeaways and what this means]

## References
[List all sources used]

---
INSIGHTS_JSON:
After the report, output a JSON array of exactly 6 key insights (plain strings, no Markdown inside):
["insight 1", "insight 2", "insight 3", "insight 4", "insight 5", "insight 6"]

SUMMARY:
Then output one concise paragraph (2-3 sentences) as the executive summary for the dashboard card.
Start with: SUMMARY_TEXT: """

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=4096,
        messages=[{"role": "user", "content": prompt}],
    )

    full_text = response.content[0].text

    # ── Parse the structured sections out of Claude's response ───────────────
    report_md = full_text
    insights  = []
    summary   = ""

    # Extract INSIGHTS_JSON block
    if "INSIGHTS_JSON:" in full_text:
        parts = full_text.split("INSIGHTS_JSON:")
        report_md = parts[0].strip()
        remainder = parts[1]

        # Find the JSON array
        start = remainder.find("[")
        end   = remainder.find("]", start)
        if start != -1 and end != -1:
            try:
                insights = json.loads(remainder[start: end + 1])
            except json.JSONDecodeError:
                insights = []

        # Extract SUMMARY_TEXT
        if "SUMMARY_TEXT:" in remainder:
            summary_raw = remainder.split("SUMMARY_TEXT:")[-1].strip()
            summary = summary_raw.split("\n")[0].strip()

    if not insights:
        insights = [
            f"Comprehensive research on {topic} completed.",
            "Multiple web sources were analyzed and deduplicated.",
            "Key trends and patterns were identified.",
            "Analysis reveals important considerations.",
            "Current state and future outlook examined.",
            "Actionable conclusions were derived.",
        ]

    if not summary:
        summary = f"A comprehensive research report on '{topic}' has been generated, covering key findings, analysis, trends, and conclusions based on multiple web sources."

    return report_md, summary, insights


def generate_report_fallback(topic: str, sources: List[Dict]) -> Tuple[str, str, List[str]]:
    """
    Fallback report generator that works WITHOUT an API key.
    Produces a structured report from the raw source content alone.
    """
    logger.warning("Using fallback report generator (no AI key)")

    sections = []
    sections.append(f"# Research Report: {topic}\n")
    sections.append("## Executive Summary\n")
    sections.append(
        f"This report presents research findings on **{topic}** compiled from "
        f"{len(sources)} web sources. The information below covers key aspects, "
        f"current developments, and important considerations related to this topic.\n"
    )

    sections.append("## Sources & Findings\n")
    for i, src in enumerate(sources, 1):
        sections.append(f"### Source {i}: {src['title']}\n")
        sections.append(f"*URL: {src['url']}*\n")
        content_preview = src["content"][:600].strip()
        sections.append(f"{content_preview}...\n")

    sections.append("## Key Observations\n")
    sections.append(
        f"Based on the gathered sources, research on **{topic}** reveals multiple "
        "perspectives and data points. Please review each source for detailed information.\n"
    )

    sections.append("## Conclusions\n")
    sections.append(
        f"The research on **{topic}** demonstrates the breadth of available information "
        "on this subject. Further investigation is recommended for a more complete understanding.\n"
    )

    sections.append("## References\n")
    for src in sources:
        sections.append(f"- [{src['title']}]({src['url']})\n")

    report_md = "\n".join(sections)
    summary   = f"Research on '{topic}' compiled from {len(sources)} sources. Add your Anthropic API key for AI-enhanced reports."
    insights  = [
        f"Found {len(sources)} unique sources on {topic}",
        "Content was deduplicated to remove redundancy",
        "Multiple web sources were consulted",
        "Add ANTHROPIC_API_KEY for AI-generated insights",
        "Report covers key findings from each source",
        "References are included for further reading",
    ]

    return report_md, summary, insights
