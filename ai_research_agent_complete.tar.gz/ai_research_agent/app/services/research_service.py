"""
app/services/research_service.py
---------------------------------
Orchestrates the full research pipeline:
  1. Search the web
  2. Fetch & deduplicate content
  3. Generate AI report
  4. Save to database
"""

import json
import logging
from datetime import datetime, timezone

from app import db
from app.models.report import Report
from app.services.search_service import collect_sources, deduplicate_content
from app.services.ai_service import generate_report, generate_report_fallback

logger = logging.getLogger(__name__)


def run_research(report_id: int):
    """
    Main pipeline. Called with a Report ID (already saved as 'pending').
    Updates the report record throughout with status and content.
    """
    report = Report.query.get(report_id)
    if not report:
        logger.error(f"Report {report_id} not found")
        return

    try:
        # ── Step 1: Mark as processing ────────────────────────────────────────
        report.status = "processing"
        db.session.commit()
        logger.info(f"[Report {report_id}] Starting research: {report.topic}")

        # ── Step 2: Search & fetch sources ───────────────────────────────────
        logger.info(f"[Report {report_id}] Searching web...")
        sources = collect_sources(report.topic, max_sources=6)

        if not sources:
            raise RuntimeError("No web sources could be retrieved. Check your internet connection.")

        # ── Step 3: Deduplicate ───────────────────────────────────────────────
        logger.info(f"[Report {report_id}] Deduplicating {len(sources)} sources...")
        sources = deduplicate_content(sources)

        # ── Step 4: Generate AI report ────────────────────────────────────────
        logger.info(f"[Report {report_id}] Generating AI report...")
        import os
        if os.getenv("ANTHROPIC_API_KEY"):
            report_md, summary, insights = generate_report(report.topic, sources)
        else:
            report_md, summary, insights = generate_report_fallback(report.topic, sources)

        # ── Step 5: Compute stats ─────────────────────────────────────────────
        word_count = len(report_md.split())
        read_time  = max(1, word_count // 200)   # ~200 wpm average reading speed

        # ── Step 6: Save results ──────────────────────────────────────────────
        report.content    = report_md
        report.summary    = summary
        report.insights   = json.dumps(insights)
        report.sources    = json.dumps([
            {"title": s["title"], "url": s["url"]} for s in sources
        ])
        report.word_count = word_count
        report.read_time  = read_time
        report.status     = "completed"
        report.updated_at = datetime.now(timezone.utc)

        db.session.commit()
        logger.info(f"[Report {report_id}] Completed ✅ ({word_count} words)")

    except Exception as exc:
        logger.error(f"[Report {report_id}] Failed: {exc}", exc_info=True)
        report.status    = "failed"
        report.error_msg = str(exc)
        db.session.commit()
