"""
app/services/search_service.py
-------------------------------
Handles web searching and content extraction.
Uses DuckDuckGo (free, no API key needed) to find URLs,
then fetches and cleans the page content.
"""

import re
import time
import logging
import requests
from typing import List, Dict
from bs4 import BeautifulSoup
try:
    from ddgs import DDGS          # new package name (ddgs)
except ImportError:
    from duckduckgo_search import DDGS   # fallback for older installs

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
}


def search_web(topic: str, max_results: int = 8) -> List[Dict]:
    """
    Search DuckDuckGo for a topic and return a list of results.
    Each result has: title, url, snippet.
    """
    results = []
    try:
        with DDGS() as ddgs:
            raw = ddgs.text(topic, max_results=max_results)
            for r in raw:
                results.append({
                    "title":   r.get("title", ""),
                    "url":     r.get("href", ""),
                    "snippet": r.get("body", ""),
                })
        logger.info(f"Found {len(results)} search results for: {topic}")
    except Exception as e:
        logger.error(f"Search failed: {e}")
    return results


def fetch_page_content(url: str, timeout: int = 10) -> str:
    """
    Fetch a webpage and extract clean text content.
    Returns empty string on failure.
    """
    try:
        resp = requests.get(url, headers=HEADERS, timeout=timeout)
        resp.raise_for_status()

        soup = BeautifulSoup(resp.text, "lxml")

        # Remove noisy tags
        for tag in soup(["script", "style", "nav", "footer",
                          "header", "aside", "form", "iframe"]):
            tag.decompose()

        # Prefer article or main content block
        body = (
            soup.find("article")
            or soup.find("main")
            or soup.find(id=re.compile(r"content|article|main", re.I))
            or soup.find(class_=re.compile(r"content|article|post|entry", re.I))
            or soup.body
        )

        if body is None:
            return ""

        text = body.get_text(separator="\n", strip=True)
        text = re.sub(r"\n{3,}", "\n\n", text)   # collapse blank lines
        text = re.sub(r"[ \t]{2,}", " ", text)    # collapse spaces

        return text[:8000]  # cap at 8 000 chars per page to stay within token limits

    except Exception as e:
        logger.warning(f"Could not fetch {url}: {e}")
        return ""


def collect_sources(topic: str, max_sources: int = 6) -> List[Dict]:
    """
    Full pipeline: search → fetch each page → return structured sources.
    Each source dict has: title, url, snippet, content.
    """
    search_results = search_web(topic, max_results=max_sources + 2)
    sources = []

    for item in search_results[:max_sources]:
        url = item["url"]
        if not url.startswith("http"):
            continue

        logger.info(f"Fetching: {url}")
        content = fetch_page_content(url)

        if len(content) < 100:          # skip near-empty pages
            content = item["snippet"]   # fall back to search snippet

        sources.append({
            "title":   item["title"],
            "url":     url,
            "snippet": item["snippet"],
            "content": content,
        })
        time.sleep(0.5)   # polite delay between requests

    return sources


def deduplicate_content(sources: List[Dict]) -> List[Dict]:
    """
    Remove sources whose content is very similar to an already-included one.
    Uses simple set-based word overlap (Jaccard similarity).
    """
    seen_sets = []
    unique = []

    for src in sources:
        words = set(re.findall(r"\w+", src["content"].lower()))
        if not words:
            unique.append(src)
            continue

        duplicate = False
        for seen in seen_sets:
            intersection = words & seen
            union        = words | seen
            if union and len(intersection) / len(union) > 0.6:   # >60% overlap
                duplicate = True
                break

        if not duplicate:
            unique.append(src)
            seen_sets.append(words)

    logger.info(f"Deduplicated: {len(sources)} → {len(unique)} sources")
    return unique
