"""
app/config.py
-------------
Configuration classes for different environments (Development, Production).
We use environment variables (.env file) for sensitive data like secret keys.
"""

import os
from datetime import timedelta

BASE_DIR = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))


class BaseConfig:
    """Settings shared across all environments."""

    # Secret key for session security & CSRF protection
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key-change-in-production-xyz123")

    # Database
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'research_agent.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Anthropic API Key (for Claude AI)
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

    # Session lifetime
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)

    # File upload folder
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "exports")
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload

    # Pagination
    REPORTS_PER_PAGE = 10

    # Plan limits (number of reports per month)
    PLAN_LIMITS = {
        "free":       3,
        "basic":      20,
        "pro":        100,
        "enterprise": 999999,
    }

    # Plan prices (USD/month) – for display only; real billing via Stripe
    PLAN_PRICES = {
        "free":       0,
        "basic":      9,
        "pro":        29,
        "enterprise": 99,
    }

    # Stripe (add your keys in .env)
    STRIPE_PUBLIC_KEY  = os.getenv("STRIPE_PUBLIC_KEY", "")
    STRIPE_SECRET_KEY  = os.getenv("STRIPE_SECRET_KEY", "")

    # App metadata
    APP_NAME = "ResearchAI"
    APP_TAGLINE = "AI-Powered Research at Your Fingertips"


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    TESTING = False


class ProductionConfig(BaseConfig):
    DEBUG = False
    TESTING = False
    # In production, always set SECRET_KEY and DATABASE_URL in environment


class TestingConfig(BaseConfig):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False


# Map name → class
config_map = {
    "development": DevelopmentConfig,
    "production":  ProductionConfig,
    "testing":     TestingConfig,
}
