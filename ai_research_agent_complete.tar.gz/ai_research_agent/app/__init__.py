"""
app/__init__.py
---------------
The Application Factory.
This file creates and configures the Flask app, registers all blueprints
(routes), and initializes all extensions (database, login, etc.).
"""

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_migrate import Migrate
from flask_wtf.csrf import CSRFProtect
from dotenv import load_dotenv
import os

# Load environment variables from .env file
load_dotenv()

# Initialize extensions (without binding to an app yet)
db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()
migrate = Migrate()
csrf = CSRFProtect()


def create_app(config_name="development"):
    """
    Application Factory Function.
    Creates and returns the configured Flask app.
    """
    app = Flask(__name__)

    # ── Load config ──────────────────────────────────────────────────────────
    from app.config import config_map
    app.config.from_object(config_map[config_name])

    # ── Bind extensions to app ───────────────────────────────────────────────
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)

    # ── Login manager settings ───────────────────────────────────────────────
    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to access this page."
    login_manager.login_message_category = "warning"

    # ── Register Blueprints (route groups) ───────────────────────────────────
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.research import research_bp
    from app.routes.admin import admin_bp
    from app.routes.api import api_bp

    app.register_blueprint(auth_bp, url_prefix="/auth")
    app.register_blueprint(dashboard_bp, url_prefix="/dashboard")
    app.register_blueprint(research_bp, url_prefix="/research")
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(api_bp, url_prefix="/api")

    # ── Root redirect ────────────────────────────────────────────────────────
    from flask import redirect, url_for
    @app.route("/")
    def index():
        return redirect(url_for("dashboard.home"))

    # ── Create DB tables if they don't exist ─────────────────────────────────
    with app.app_context():
        db.create_all()
        _seed_admin()

    return app


def _seed_admin():
    """Create a default admin user on first run if none exists."""
    from app.models.user import User
    if not User.query.filter_by(role="admin").first():
        admin = User(
            username="admin",
            email=os.getenv("ADMIN_EMAIL", "admin@researchai.com"),
            role="admin",
            plan="enterprise",
            is_active=True,
        )
        admin.set_password(os.getenv("ADMIN_PASSWORD", "Admin@12345"))
        db.session.add(admin)
        db.session.commit()
        print("✅ Default admin created: admin@researchai.com / Admin@12345")
