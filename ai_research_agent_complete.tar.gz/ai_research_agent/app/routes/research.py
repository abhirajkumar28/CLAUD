"""
app/routes/research.py
-----------------------
Routes for creating new research jobs and viewing completed reports.
"""

import threading
from flask import (Blueprint, render_template, redirect, url_for,
                   flash, request, current_app, send_file, abort)
from flask_login import login_required, current_user
from app import db
from app.models.report import Report
from app.services.research_service import run_research
from app.services.export_service import export_pdf, export_docx

research_bp = Blueprint("research", __name__)


@research_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_research():
    """Show the 'Start Research' form and handle submission."""

    plan_limit      = current_app.config["PLAN_LIMITS"].get(current_user.plan, 3)
    used_this_month = current_user.reports_this_month()

    if request.method == "POST":
        topic = request.form.get("topic", "").strip()

        if not topic:
            flash("Please enter a research topic.", "warning")
            return render_template("research/new.html",
                                   plan_limit=plan_limit, used=used_this_month)

        if len(topic) > 500:
            flash("Topic is too long. Please keep it under 500 characters.", "warning")
            return render_template("research/new.html",
                                   plan_limit=plan_limit, used=used_this_month)

        # Check monthly limit
        if used_this_month >= plan_limit:
            flash(
                f"You've reached your {current_user.plan} plan limit of "
                f"{plan_limit} reports/month. Upgrade to continue.",
                "danger",
            )
            return redirect(url_for("dashboard.pricing"))

        # Create report record
        report = Report(user_id=current_user.id, topic=topic, status="pending")
        db.session.add(report)
        db.session.commit()

        # Run research in a background thread (so the page loads immediately)
        thread = threading.Thread(
            target=_run_in_context,
            args=(current_app._get_current_object(), report.id),
            daemon=True,
        )
        thread.start()

        flash("Research started! Your report will be ready in about 30-60 seconds.", "info")
        return redirect(url_for("research.view_report", report_id=report.id))

    return render_template("research/new.html",
                           plan_limit=plan_limit, used=used_this_month)


def _run_in_context(app, report_id):
    """Run the research pipeline inside the Flask app context (needed for DB access in threads)."""
    with app.app_context():
        run_research(report_id)


@research_bp.route("/report/<int:report_id>")
@login_required
def view_report(report_id):
    """Show a specific research report."""
    report = Report.query.get_or_404(report_id)

    # Security: only owner or admin can view
    if report.user_id != current_user.id and not current_user.is_admin():
        abort(403)

    import json
    insights = []
    sources  = []
    if report.insights:
        try:
            insights = json.loads(report.insights)
        except Exception:
            pass
    if report.sources:
        try:
            sources = json.loads(report.sources)
        except Exception:
            pass

    return render_template(
        "research/report.html",
        report=report,
        insights=insights,
        sources=sources,
    )


@research_bp.route("/report/<int:report_id>/delete", methods=["POST"])
@login_required
def delete_report(report_id):
    report = Report.query.get_or_404(report_id)
    if report.user_id != current_user.id and not current_user.is_admin():
        abort(403)
    db.session.delete(report)
    db.session.commit()
    flash("Report deleted.", "info")
    return redirect(url_for("dashboard.home"))


@research_bp.route("/report/<int:report_id>/export/pdf")
@login_required
def export_report_pdf(report_id):
    report = Report.query.get_or_404(report_id)
    if report.user_id != current_user.id and not current_user.is_admin():
        abort(403)
    if report.status != "completed":
        flash("Report is not ready yet.", "warning")
        return redirect(url_for("research.view_report", report_id=report_id))

    try:
        path = export_pdf(report)
        db.session.commit()
        return send_file(path, as_attachment=True,
                         download_name=f"research_{report_id}.pdf")
    except Exception as e:
        flash(f"PDF export failed: {e}", "danger")
        return redirect(url_for("research.view_report", report_id=report_id))


@research_bp.route("/report/<int:report_id>/export/docx")
@login_required
def export_report_docx(report_id):
    report = Report.query.get_or_404(report_id)
    if report.user_id != current_user.id and not current_user.is_admin():
        abort(403)
    if report.status != "completed":
        flash("Report is not ready yet.", "warning")
        return redirect(url_for("research.view_report", report_id=report_id))

    try:
        path = export_docx(report)
        db.session.commit()
        return send_file(path, as_attachment=True,
                         download_name=f"research_{report_id}.docx")
    except Exception as e:
        flash(f"DOCX export failed: {e}", "danger")
        return redirect(url_for("research.view_report", report_id=report_id))
