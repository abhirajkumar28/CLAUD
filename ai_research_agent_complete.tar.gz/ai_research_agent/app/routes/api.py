"""
app/routes/api.py
-----------------
JSON API endpoints used by the frontend JavaScript.
Mainly for polling report status without a full page reload.
"""

from flask import Blueprint, jsonify, abort
from flask_login import login_required, current_user
from app.models.report import Report

api_bp = Blueprint("api", __name__)


@api_bp.route("/report/<int:report_id>/status")
@login_required
def report_status(report_id):
    """Return JSON with the current status of a report (for polling)."""
    report = Report.query.get_or_404(report_id)

    if report.user_id != current_user.id and not current_user.is_admin():
        abort(403)

    return jsonify({
        "id":         report.id,
        "status":     report.status,
        "word_count": report.word_count,
        "read_time":  report.read_time,
        "error_msg":  report.error_msg,
    })


@api_bp.route("/dashboard/stats")
@login_required
def dashboard_stats():
    """Quick stats for the dashboard page."""
    from app import db
    from app.models.report import Report as R
    from flask import current_app

    total     = R.query.filter_by(user_id=current_user.id).count()
    completed = R.query.filter_by(user_id=current_user.id, status="completed").count()
    limit     = current_app.config["PLAN_LIMITS"].get(current_user.plan, 3)
    used      = current_user.reports_this_month()

    return jsonify({
        "total_reports":    total,
        "completed_reports": completed,
        "plan":             current_user.plan,
        "plan_limit":       limit,
        "used_this_month":  used,
        "remaining":        max(0, limit - used),
    })
