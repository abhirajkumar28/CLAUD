"""
app/routes/admin.py
--------------------
Admin-only panel: user management, system stats, plan upgrades.
"""

from functools import wraps
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app import db
from app.models.user import User
from app.models.report import Report

admin_bp = Blueprint("admin", __name__)


def admin_required(f):
    """Decorator: redirects non-admins to 403."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            abort(403)
        return f(*args, **kwargs)
    return decorated


@admin_bp.route("/")
@login_required
@admin_required
def dashboard():
    total_users   = User.query.count()
    total_reports = Report.query.count()
    active_users  = User.query.filter_by(is_active=True).count()
    failed_reports = Report.query.filter_by(status="failed").count()

    plan_counts = {
        "free":       User.query.filter_by(plan="free").count(),
        "basic":      User.query.filter_by(plan="basic").count(),
        "pro":        User.query.filter_by(plan="pro").count(),
        "enterprise": User.query.filter_by(plan="enterprise").count(),
    }

    recent_users   = User.query.order_by(User.created_at.desc()).limit(10).all()
    recent_reports = Report.query.order_by(Report.created_at.desc()).limit(10).all()

    return render_template(
        "admin/dashboard.html",
        total_users=total_users,
        total_reports=total_reports,
        active_users=active_users,
        failed_reports=failed_reports,
        plan_counts=plan_counts,
        recent_users=recent_users,
        recent_reports=recent_reports,
    )


@admin_bp.route("/users")
@login_required
@admin_required
def users():
    page  = request.args.get("page", 1, type=int)
    query = request.args.get("q", "").strip()

    q = User.query
    if query:
        q = q.filter(
            User.username.ilike(f"%{query}%") |
            User.email.ilike(f"%{query}%")
        )
    users_page = q.order_by(User.created_at.desc()).paginate(page=page, per_page=20)

    return render_template("admin/users.html", users=users_page, query=query)


@admin_bp.route("/users/<int:user_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot deactivate yourself.", "warning")
    else:
        user.is_active = not user.is_active
        db.session.commit()
        status = "activated" if user.is_active else "deactivated"
        flash(f"User {user.username} has been {status}.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/plan", methods=["POST"])
@login_required
@admin_required
def change_plan(user_id):
    user = User.query.get_or_404(user_id)
    new_plan = request.form.get("plan")
    if new_plan in ("free", "basic", "pro", "enterprise"):
        user.plan = new_plan
        db.session.commit()
        flash(f"Plan for {user.username} changed to {new_plan}.", "success")
    else:
        flash("Invalid plan.", "danger")
    return redirect(url_for("admin.users"))


@admin_bp.route("/reports")
@login_required
@admin_required
def reports():
    page   = request.args.get("page", 1, type=int)
    status = request.args.get("status", "")

    q = Report.query
    if status:
        q = q.filter_by(status=status)
    reports_page = q.order_by(Report.created_at.desc()).paginate(page=page, per_page=20)

    return render_template("admin/reports.html", reports=reports_page, status_filter=status)


@admin_bp.route("/reports/<int:report_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_report(report_id):
    report = Report.query.get_or_404(report_id)
    db.session.delete(report)
    db.session.commit()
    flash("Report deleted.", "info")
    return redirect(url_for("admin.reports"))
