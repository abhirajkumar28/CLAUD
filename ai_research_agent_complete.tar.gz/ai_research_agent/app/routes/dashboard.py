"""
app/routes/dashboard.py
------------------------
User dashboard: shows research history, stats, plan info.
"""

from flask import Blueprint, render_template, current_app
from flask_login import login_required, current_user
from app.models.report import Report

dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/")
@dashboard_bp.route("/home")
@login_required
def home():
    page = 1
    per_page = current_app.config["REPORTS_PER_PAGE"]

    reports = (
        Report.query
        .filter_by(user_id=current_user.id)
        .order_by(Report.created_at.desc())
        .paginate(page=page, per_page=per_page, error_out=False)
    )

    # Stats for dashboard cards
    total_reports    = Report.query.filter_by(user_id=current_user.id).count()
    completed_reports = Report.query.filter_by(user_id=current_user.id, status="completed").count()
    plan_limit       = current_app.config["PLAN_LIMITS"].get(current_user.plan, 3)
    used_this_month  = current_user.reports_this_month()

    return render_template(
        "dashboard/home.html",
        reports=reports,
        total_reports=total_reports,
        completed_reports=completed_reports,
        plan_limit=plan_limit,
        used_this_month=used_this_month,
    )


@dashboard_bp.route("/history")
@login_required
def history():
    from flask import request
    page = request.args.get("page", 1, type=int)

    reports = (
        Report.query
        .filter_by(user_id=current_user.id)
        .order_by(Report.created_at.desc())
        .paginate(page=page, per_page=10, error_out=False)
    )
    return render_template("dashboard/history.html", reports=reports)


@dashboard_bp.route("/pricing")
def pricing():
    plan_prices = current_app.config["PLAN_PRICES"]
    plan_limits = current_app.config["PLAN_LIMITS"]
    return render_template("dashboard/pricing.html",
                           plan_prices=plan_prices, plan_limits=plan_limits)
