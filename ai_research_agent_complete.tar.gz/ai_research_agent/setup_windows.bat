@echo off
REM ============================================================
REM  setup_windows.bat
REM  Run this ONCE to set up the project on Windows
REM  Double-click this file or run it in Command Prompt
REM ============================================================

echo.
echo  ========================================
echo   ResearchAI - Windows Setup Script
echo  ========================================
echo.

REM Check Python is installed
python --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo  ERROR: Python is not installed or not in PATH.
    echo  Download Python from: https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during install!
    pause
    exit /b 1
)

echo  [1/5] Python found. Creating virtual environment...
python -m venv venv

echo  [2/5] Activating virtual environment...
call venv\Scripts\activate.bat

echo  [3/5] Upgrading pip...
python -m pip install --upgrade pip

echo  [4/5] Installing dependencies...
pip install -r requirements.txt

echo  [5/5] Setting up environment file...
IF NOT EXIST .env (
    copy .env.example .env
    echo  Created .env file from template.
    echo  IMPORTANT: Open .env and add your ANTHROPIC_API_KEY!
) ELSE (
    echo  .env file already exists - skipping.
)

echo.
echo  ========================================
echo   Setup Complete!
echo  ========================================
echo.
echo  NEXT STEPS:
echo  1. Open .env in Notepad and add your API key
echo  2. Run: venv\Scripts\activate
echo  3. Run: python run.py
echo  4. Open browser: http://127.0.0.1:5000
echo.
echo  Admin login:
echo    Email:    admin@researchai.com
echo    Password: Admin@12345
echo.
pause
