#!/bin/bash
# ============================================================
#  setup_linux.sh
#  Run this ONCE to set up the project on Linux / Mac
#  Usage:  chmod +x setup_linux.sh && ./setup_linux.sh
# ============================================================

set -e   # Exit immediately if a command fails

echo ""
echo "========================================"
echo "  ResearchAI - Linux/Mac Setup Script"
echo "========================================"
echo ""

# ── Check Python ─────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 not found."
    echo "Install it with:  sudo apt install python3 python3-pip python3-venv"
    exit 1
fi

echo "[1/6] Python3 found: $(python3 --version)"

# ── System dependencies (Ubuntu/Debian) ──────────────────────
echo "[2/6] Installing system dependencies..."
if command -v apt-get &>/dev/null; then
    sudo apt-get update -qq
    sudo apt-get install -y python3-venv python3-pip libxml2-dev libxslt-dev 2>/dev/null || true
fi

# ── Virtual environment ───────────────────────────────────────
echo "[3/6] Creating virtual environment..."
python3 -m venv venv

echo "[4/6] Activating virtual environment..."
source venv/bin/activate

# ── Install dependencies ──────────────────────────────────────
echo "[5/6] Installing Python dependencies..."
pip install --upgrade pip -q
pip install -r requirements.txt -q

# ── Environment file ──────────────────────────────────────────
echo "[6/6] Setting up .env file..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "  Created .env from template."
    echo "  IMPORTANT: Edit .env and add your ANTHROPIC_API_KEY!"
else
    echo "  .env already exists - skipping."
fi

# ── Exports folder ────────────────────────────────────────────
mkdir -p exports

echo ""
echo "========================================"
echo "  Setup Complete!"
echo "========================================"
echo ""
echo "NEXT STEPS:"
echo "  1. Edit .env and add your ANTHROPIC_API_KEY"
echo "  2. source venv/bin/activate"
echo "  3. python run.py"
echo "  4. Open: http://127.0.0.1:5000"
echo ""
echo "Admin login:"
echo "  Email:    admin@researchai.com"
echo "  Password: Admin@12345"
echo ""
